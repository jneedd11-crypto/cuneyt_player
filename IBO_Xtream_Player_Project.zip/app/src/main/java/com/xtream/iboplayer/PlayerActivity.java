package com.xtream.iboplayer;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.ui.StyledPlayerView;

public class PlayerActivity extends AppCompatActivity {

    private StyledPlayerView playerView;
    private ExoPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        playerView = findViewById(R.id.playerView);

        SharedPreferences prefs = getSharedPreferences("XtreamPrefs", MODE_PRIVATE);
        String serverUrl = prefs.getString("server_url", "");
        String user = prefs.getString("username", "");
        String pass = prefs.getString("password", "");

        if (!serverUrl.endsWith("/")) {
            serverUrl += "/";
        }

        // Demo Stream URL Construction for Xtream Live/VOD
        String streamUrl = serverUrl + "live/" + user + "/" + pass + "/1.m3u8";

        initializePlayer(streamUrl);
    }

    private void initializePlayer(String url) {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);

        MediaItem mediaItem = MediaItem.fromUri(Uri.parse(url));
        player.setMediaItem(mediaItem);
        player.prepare();
        player.setPlayWhenReady(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
