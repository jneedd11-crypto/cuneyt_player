package com.xtream.iboplayer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private Button btnLiveTv, btnMovies, btnSeries, btnLogout;
    private TextView tvUserInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        btnLiveTv = findViewById(R.id.btnLiveTv);
        btnMovies = findViewById(R.id.btnMovies);
        btnSeries = findViewById(R.id.btnSeries);
        btnLogout = findViewById(R.id.btnLogout);
        tvUserInfo = findViewById(R.id.tvUserInfo);

        SharedPreferences prefs = getSharedPreferences("XtreamPrefs", MODE_PRIVATE);
        String user = prefs.getString("username", "User");
        tvUserInfo.setText("مرحباً بك: " + user);

        btnLiveTv.setFocusable(true);
        btnMovies.setFocusable(true);
        btnSeries.setFocusable(true);
        btnLogout.setFocusable(true);

        btnLiveTv.requestFocus();

        btnLiveTv.setOnClickListener(v -> openPlayer("live"));
        btnMovies.setOnClickListener(v -> openPlayer("movie"));
        btnSeries.setOnClickListener(v -> openPlayer("series"));

        btnLogout.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            startActivity(new Intent(DashboardActivity.class, LoginActivity.class));
            finish();
        });
    }

    private void openPlayer(String type) {
        Intent intent = new Intent(DashboardActivity.this, PlayerActivity.class);
        intent.putExtra("type", type);
        startActivity(intent);
    }
}
